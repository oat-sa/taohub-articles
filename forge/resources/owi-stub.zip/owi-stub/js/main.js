(function($){

//define a global function 'onItemApiReady' that gives you the reference to itemApi
window.onItemApiReady = function(itemApi){
	
	$('#submiter').click(function(){

		var result = parseInt($(':input[name="sum"]').val(), 10);
		
		itemApi.beforeFinish(function(){
			alert('Submiting your results')
		});

		itemApi.saveResponses({'sum' : result});
		itemApi.finish();

		return false;
	});

};

}(jQuery));
