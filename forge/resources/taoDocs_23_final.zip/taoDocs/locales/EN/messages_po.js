/* auto generated content */
/* lang: EN */
var langCode = 'EN';
var i18n_tr = [];