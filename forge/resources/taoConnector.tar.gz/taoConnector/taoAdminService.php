<?php

require_once(dirname(__FILE__)."/lib/taoLibrary.php");

/**
 * 
 * Administrativ Services, might not be available to all users
 * 
 * @author Joel Bout, <joel.bout@tudor.lu>
 *
 */
class taoAdminService extends taoLibrary {
	
	/**
	 * module used by this library
	 * @var string
	 */
	const MODULE = 'UserAdminApi';
	
	/**
	 * Returns a list of all users 
	 * 
	 * @return array
	 */
	public function getAllUsers() {
		$data = $this->request(self::MODULE, 'getAllUsers', array());
		return $data['list'];
	}
	
	/**
	 * Returns an associativ array with the role uris as keys
	 * an the roles labels as values
	 * 
	 * @return array 
	 */
	public function getAllRoles() {
		$data = $this->request(self::MODULE, 'getAllRoles', array());
		return $data['list'];
	}
	
	/**
	 * Return informations on a specific user
	 * 
	 * @param string $userUri
	 * @see taoLibrary::startSession()
	 */
	public function getUserInfo($userUri) {
		$data = $this->request(self::MODULE, 'getUserInfo', array(
			'userid'	=> $userUri
		));
		if (is_null($data) || !isset($data['info']) || !isset($data['success']) || !$data['success']) {
			$this->handleError('User info cannot be retrieved');
			return false;
		}
		return $data['info'];
	}
	
	/**
	 * NOT IMPLEMENTED, since no information besides label
	 * exists for the role at the moment
	 * 
	 * @throws Exception
	 */
	public function getRoleInfo() {
		throw new Exception('not implemented');
	}
	
	/**
	 * Returns a list of the specified user's roles 
	 * 
	 * @param string $userUri
	 * @return array
	 * @see taoAdminService::getAllRoles()
	 */
	public function getUserRoles($userUri) {
		$data = $this->request(self::MODULE, 'getUserRoles', array('userid' => $userUri));
		return $data['roles'];
	}

	/**
	 * Returns a list of the users that have the specified role
	 * 
	 * @param string $groupUri
	 * @return array
	 */
	public function getRoleUsers($groupUri) {
		$data = $this->request(self::MODULE, 'getRoleUsers', array('groupid' => $groupUri));
		return $data['users'];
	}
}
		