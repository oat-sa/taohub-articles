<?php
/**
 * this exception is thrown when a request could not be
 * completed or its response not handled
 *  
 * @author Joel Bout, <joel.bout@tudor.lu>
 */
class taoCommunicationException extends Exception {
	
}