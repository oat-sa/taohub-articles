<?php
/**
 * this exception is thrown when a service requiring a session
 * is called while there is no session
 *  
 * @author Joel Bout, <joel.bout@tudor.lu>
 */
class taoSessionRequiredException extends Exception {
	
}