<?php

require_once(dirname(__FILE__)."/lib/taoLibrary.php");

/**
 * Tao basic user functionalities, includes
 * password and language changes
 * 
 * @author Joel Bout, <joel.bout@tudor.lu>
 */
class taoUserService extends taoLibrary {
	
	/**
	 * module used by this library
	 * @var string
	 */
	const MODULE = 'UserApi';
	
	/**
	 * Returns informations on the current user
	 * 
	 * @return array
	 * @see taoLibrary::startSession()
	 */
	public function getInfo() {
		$data = $this->request(self::MODULE, 'getSelfInfo', array());
		if (is_null($data) || !isset($data['info']) || !isset($data['success']) || !$data['success']) {
			return $this->handleError('getInfo request failed');
		}
		return $data['info'];
	}
	
	/**
	 * Returns the roles of the current user with the roles uris as key
	 * and the roles labels as value
	 * 
	 * @return array
	 */
	public function getRoles() {
		$info = $this->getInfo();
		if (isset($info['roles'])) {
			return $info['roles'];
		} else {
			// error already handled in getInfo
			return $info;
		}
	}
	
	/**
	 * Sets the currents user language
	 * 
	 * @param string $lang language to chnage to
	 * @return boolean whenever or not the changes were successful
	 */
	public function setLanguage($lang) {
		$reply = $this->request(self::MODULE, 'setInterfaceLanguage', array(
			'lang'		=> $lang
		));
		return (!is_null($reply) && isset($reply['success']) && $reply['success']);
	}
	
	/**
	 * Change the current users password
	 * 
	 * @param string $old the old password
	 * @param string $new the new password
	 * @return boolean whenever or not the password was changed
	 */
	public function changePassword($old, $new) {
		$reply = $this->request(self::MODULE, 'changePassword', array(
			'oldpassword'	=> $old,
			'newpassword'	=> $new
		));
		
		return (!is_null($reply) && isset($reply['success']) && $reply['success']);
	}
}
		