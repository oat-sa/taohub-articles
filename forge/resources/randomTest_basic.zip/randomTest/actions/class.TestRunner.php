<?php

/**
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Copyright (c) 2013 (original work) Open Assessment Techonologies SA (under the project TAO-PRODUCT);
 *               
 * 
 */

/**
 * Runs a Random Test.
 *
 * @author Joel Bout, <joel@taotesting.com>
 * @package randomTest
 * @subpackage actions
 * @license GPLv2  http://www.opensource.org/licenses/gpl-2.0.php
 */
class randomTest_actions_TestRunner extends tao_actions_ServiceModule {

    public function __construct() {
        parent::__construct();
    }
    
    /**
     * Entrypoint of the random TestRunner module.
     * 
     */
	public function index()
	{
	    // gets a random item
	    $item = $this->getRandomItem();
	    
	    $serviceCall = tao_models_classes_service_ServiceCall::fromString($item['runtime']);
	    $serviceCallId = md5($this->getServiceCallId());
	    
	    $call = tao_helpers_ServiceJavascripts::getServiceApi($serviceCall, $serviceCallId);
	    $this->setData('jsServiceApi', $call);
	    $this->setView('testrunner.tpl');
	}
	    
    /**
     * Select an item by random
     * 
     * @return array
     */
	private function getRandomItem() {
        $items = $this->getContent();
        $keys = array_keys($items);
        $key = $keys[rand(0, count($keys)-1)];
        return $items[$key];
    }

    /**
     * Loads the content that was created during compilation
     * @return array
     */
    private function getContent()
	{
	    $file = new core_kernel_file_File($this->getRequestParameter('file'));
	    return include $file->getAbsolutePath();
	}
}
