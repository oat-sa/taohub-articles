<?php
/**  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Copyright (c) 2013 (original work) Open Assessment Technologies SA (under the project TAO-PRODUCT);
 * 
 */

/**
 * Compiles a test and item
 *
 * @access public
 * @author Joel Bout, <joel@taotesting.com>
 * @package taoDelivery
 * @subpackage models_classes
 */
class randomTest_models_classes_TestCompiler extends tao_models_classes_Compiler
{
    public function __construct(core_kernel_classes_Resource $test) {
        parent::__construct($test);
        common_ext_ExtensionsManager::singleton()->getExtensionById('taoWfTest'); // loads the extension
    }
	
    public function compile(core_kernel_file_File $destinationDirectory) {
        
        // iterate over the items in our test, compile the items and store them in our data array
        $data = array();
        foreach (taoTests_models_classes_TestsService::singleton()->getTestItems($this->getResource()) as $item) {
            $data[] = array(
                'label'   => $item->getLabel(),
            	'runtime' => $this->getItemRunnerService($item, $destinationDirectory)->serializeToString()
            );
        }
        
        // store the data array in a file
        $dataFile = $destinationDirectory->getFileSystem()->createFile('data.php', $destinationDirectory->getRelativePath());
        
        $dataFile->setContent("<?php return ".common_Utils::toPHPVariableString($data).";?>");
        
        // create a call to the testrunner, with out file as parameter
        $serviceCall = new tao_models_classes_service_ServiceCall(new core_kernel_classes_Resource(INSTANCE_SERVICE_RANDOMTEST_RUNNER));
        $serviceCall->addInParameter(new tao_models_classes_service_ConstantParameter(
            new core_kernel_classes_Resource(INSTANCE_FORMAL_PARAM_COMPILED_TEST_FILE),
            $dataFile->getUri()
        ));
        return $serviceCall;
    }
    
    /**
     * 
     * @param core_kernel_classes_Resource $item
     * @param core_kernel_file_File $destinationDirectory
     * @return tao_models_classes_service_ServiceCall
     */
    protected function getItemRunnerService(core_kernel_classes_Resource $item, core_kernel_file_File $destinationDirectory)
    {
        $itemDirectory = $this->createSubDirectory($destinationDirectory, $item);
        $compiler = taoItems_models_classes_ItemsService::singleton()->getCompiler($item);
        $callService = $compiler->compile($itemDirectory);
        return $callService;
    }
}