<?php

/**
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Copyright (c) 2013 (original work) Open Assessment Technologies SA (under the project TAO-PRODUCT);
 *               
 * 
 */

/**
 * the random TestModel
 * 
 * Very simple testmodel, which stores no informations
 * features no authoring, and a very simple runner
 *
 * @access public
 * @author Joel Bout, <joel.bout@tudor.lu>
 * @package taoQtiTest
 * @subpackage models_classes
 */
class randomTest_models_classes_TestModel
	implements taoTests_models_classes_TestModel
{
    // --- ASSOCIATIONS ---


    // --- ATTRIBUTES ---

    // --- OPERATIONS ---
    /**
     * default constructor to ensure the implementation
     * can be instanciated
     */
    public function __construct() {
        common_ext_ExtensionsManager::singleton()->getExtensionById('randomTest');
    }
    
    /**
     * (non-PHPdoc)
     * @see taoTests_models_classes_TestModel::prepareContent()
     */
    public function prepareContent( core_kernel_classes_Resource $test, $items = array()) {
        // nothing to prepare
    }
    
    /**
     * (non-PHPdoc)
     * @see taoTests_models_classes_TestModel::deleteContent()
     */
    public function deleteContent( core_kernel_classes_Resource $test) {
        // nothing saved nothing to delete
    }
    
    /**
     * (non-PHPdoc)
     * @see taoTests_models_classes_TestModel::getItems()
     */
    public function getItems( core_kernel_classes_Resource $test) {
        $itemClass = new core_kernel_classes_Class(TAO_ITEM_CLASS);
        return $itemClass->getInstances(true);
    }

    /**
     * (non-PHPdoc)
     * @see taoTests_models_classes_TestModel::onChangeTestLabel()
     */
    public function onChangeTestLabel( core_kernel_classes_Resource $test) {
    	// do nothing
    }
    
    /**
     * (non-PHPdoc)
     * @see taoTests_models_classes_TestModel::getAuthoring()
     */
    public function getAuthoring( core_kernel_classes_Resource $test) {
        // no authoring
        return '';
    }
    
    public function cloneContent( core_kernel_classes_Resource $source, core_kernel_classes_Resource $destination) {
        // nothing to clone
    }
    
    public function getcompiler(core_kernel_classes_Resource $test) {
        return new randomTest_models_classes_TestCompiler($test);
    }
    
}