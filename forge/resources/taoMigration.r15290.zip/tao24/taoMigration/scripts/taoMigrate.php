<?php
/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Copyright (c) 2013 (original work) Open Assessment Techonologies SA (under the project TAO-PRODUCT);
 */

/**
 * @author  Lionel Lecaque, <lionel@taotesting.com>
 */

require_once dirname(__FILE__) .'/../includes/raw_start.php';

common_log_Dispatcher::singleton()->init(array(
	array(
		'class'			=> 'SingleFileAppender',
		'threshold'		=> 1 ,
		'file'			=> dirname(__FILE__).'/migration.log',
)));


new taoMigration_scripts_Migration(array(
	'min' => 4,
	'parameters' => array(
array(
			'name' => 'driver',
			'type' => 'string',
			'shortcut' => 'd',
			'description' => 'Database driver option mysql,postgres'
			),
			array(
			'name' => 'host',
			'type' => 'string',
			'shortcut' => 'host',
			'description' => 'Database host'
			),
			array(
      			'name' => 'db',
      			'type' => 'string',
      			'shortcut' => 'db',
      			'description' => 'Database name'
      			),
      			array(
      			'name' => 'user',
      			'type' => 'string',
      			'shortcut' => 'u',
      			'description' => 'Database user'
      			),
      			array(
      			'name' => 'pass',
      			'type' => 'string',
      			'shortcut' => 'p',
      			'description' => 'Database password'
      			),
      			array(
      			'name' => 'lang',
      			'type' => 'string',
      			'shortcut' => 'l',
      			'description' => 'Language to migrate'
      			),
      			array(
      			'name' => 'namespace',
      			'type' => 'string',
      			'shortcut' => 'ns',
      			'description' => 'Old Namespace to migrate '
      			),
      			array(
      			'name' => 'option',
      			'type' => 'string',
      			'shortcut' => 'o',
      			'description' => 'what to migrate, options available: testtakers, items, users, all'
      			),
      			)
      			)
      			);
				