<?php
/*  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Copyright (c) 2002-2008 (original work) Public Research Centre Henri Tudor & University of Luxembourg (under the project TAO & TAO2);
 *               2008-2010 (update and modification) Deutsche Institut für Internationale Pädagogische Forschung (under the project TAO-TRANSFER);
 *               2009-2012 (update and modification) Public Research Centre Henri Tudor (under the project TAO-SUSTAIN & TAO-DEV);
 * 
 */

/**
 * The UserService aims at providing an API to manage Users and Roles within Generis.
 *
 * @access public
 * @author Lionel Lecaque, <lionel@taotesting.com>
 * @package taoMigration
 * @subpackage scripts_Migration
 */

class taoMigration_scripts_Migration extends tao_scripts_Runner
{

	/**
	 * @access protected
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @return mixed
	 */
	protected function run()
	{
		$host = $this->options['host'];
		$login =  $this->options['user'];
		$pass = $this->options['pass'];
		$driver = $this->options['driver'];
		$db = $this->options['db'];
				$lg = $this->options['lang'];
		self::out("Start migration from " . $db );
		$dbConnector = new taoMigration_models_classes_DistantDbConnector($host,$login,$pass,$driver,$db);
		$service = taoMigration_models_classes_MigrationService::singleton();
		$service->initDb($dbConnector,$lg);

		switch($this->options['option']){
			case 'items' : $service->migrateItems();break;
			case 'testtakers' : $service->migrateSubjects();break;
			case 'users' : $service->migrateUsers();break;
			default :
				$service->migrateItems();
				$service->migrateSubjects();
				$service->migrateUsers();

		}
		self::out("Migration Complete see log : " . dirname(__FILE__).'/migration.log');

	}

	/**
	 * 
	 * @access protected
	 */
	public function preRun(){

		$this->options = array (
   			"driver"	=>	"mysql"
   			, "host"	=>	"localhost"
   			, "db"	=>		null
   			, "pass"	=>	null
   			, "user"	=>	null
   			, "lang"	=>	"EN"
   			, "option"	=>	"all"

   			);
   			$this->options = array_merge($this->options, $this->parameters);

   			$this->options['driver'] = strtolower($this->options['driver']);
   			$allowedDrivers = array('mysql','pgsql','sqlsrv');
   			if (!in_array($this->options['driver'], $allowedDrivers)) {
   				self::err("'" . $this->options['driver'] . "' is not a valid driver.", true);
   			}
   			$this->options['option'] = strtolower($this->options['option']);
   			$allowedOptions = array('all','testtaker','items','users');
   			if (!in_array($this->options['option'], $allowedOptions)) {
   				self::err("'" . $this->options['option'] . "' is not a valid option, 'all','testtakers','items'", true);
   			}


   			if ($this->options['db'] == null){
   				self::err("Please provide a database 'name'.", true);
   			}
   			else if ($this->options['pass'] == null){
   				self::err("Please provide a  database 'password'.", true);
   			}
   			else if ($this->options['user'] == null){
   				self::err("Please provide a database 'user' .", true);
   			}


	}




}
