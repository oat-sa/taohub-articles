<?php
/**
 * Subjects Controller provide actions performed from url resolution
 * 
 * @author Bertrand Chevrier, <taosupport@tudor.lu>
 * @package taoMigration
 * @subpackage actions
 * @license GPLv2  http://www.opensource.org/licenses/gpl-2.0.php
 * 
 */

class taoMigration_actions_TestController extends tao_actions_CommonModule {

	/**
	 * the say  action 
	 * @return 
	 */
	public function sayHello(){

        echo 'hello';
	}
	

}
?>