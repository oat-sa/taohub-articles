<?php
require_once dirname(__FILE__) . '/../../tao/test/TaoTestRunner.php';
include_once dirname(__FILE__) . '/../includes/raw_start.php';


class MigrationTestCase extends UnitTestCase {

	protected $service = null;

	public function setUp(){

		$host = 'localhost';
		$login = 'tao23';
		$pass = 'tao';
		$driver = 'mysql';
		$db = 'tao23';
		$ns = 'tao23.localdomain';
		$lg = 'EN';

		$dbConnector = new taoMigration_models_classes_DistantDbConnector($host,$login,$pass,$driver,$db);
		$this->service = taoMigration_models_classes_MigrationService::singleton();
		$this->service->initDb($dbConnector,$ns,$lg);
	}

/*	public function testMigrateItems(){
		$this->service->migrateItems();

	}
	

	public function testMigrateSubjects(){
		$this->service->migrateSubjects();

	}
	

	
	public function testMigrateUser(){
		$this->service->migrateUsers();

	}
	*/
	public function testGetDomain(){
		$ns = 'http://tao23.localdomain/demo.rdf#test';
		var_dump(tao_helpers_Uri::getDomain($ns), tao_helpers_Uri::getPath($ns));
		$a= substr($ns, 0, strpos($ns, '#'));
		$toto = array_keys(common_ext_NamespaceManager::singleton()->getAllNamespaces());
		var_dump($a,$toto);
		echo 'array(';
		foreach ($toto as  $value) {
			echo "'".$value."',";
		}
	}
	
}