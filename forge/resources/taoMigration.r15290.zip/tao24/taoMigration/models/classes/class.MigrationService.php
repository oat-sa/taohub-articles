<?php
/**
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Copyright (c) 2013 (original work) Open Assessment Techonologies SA (under the project TAO-PRODUCT);
 */

/**
 * @author  Lionel Lecaque, <lionel@taotesting.com>
 * @package tao
 * @subpackage models_classes
 */

class taoMigration_models_classes_MigrationService extends tao_models_classes_Service
{

	private $currentDbWrapper;
	private $currentDefaultLg;
	private $oldDbWrapper;
	private $oldDefaultLg;
	private $migrationHistory = array();
	private $missingPropertyValues = array();

	private $namespaceToIgnore =  array(
				'http://www.tao.lu/datatypes/WidgetDefinitions.rdf',
				'http://www.w3.org/1999/02/22-rdf-syntax-ns',
				'http://www.w3.org/2000/01/rdf-schema',
				'http://www.tao.lu/Ontologies/generis.rdf',
				'http://www.tao.lu/Ontologies/TAO.rdf',
				'http://www.tao.lu/Ontologies/TAOResult.rdf',
				'http://www.tao.lu/Ontologies/TAOItem.rdf',
				'http://www.tao.lu/Ontologies/TAOGroup.rdf',
				'http://www.tao.lu/Ontologies/TAOTest.rdf',
				'http://www.tao.lu/Ontologies/TAOSubject.rdf',
				'http://www.tao.lu/Ontologies/TAODelivery.rdf',
				'http://www.tao.lu/middleware/wfEngine.rdf',
				'http://www.tao.lu/middleware/Rules.rdf',
				'http://www.tao.lu/Ontologies/taoFuncACL.rdf',
				'http://www.tao.lu/Ontologies/filemanager.rdf',			
	);
	
	private $userProps = array(
	    'http://www.w3.org/2000/01/rdf-schema#label',
	    'http://www.w3.org/2000/01/rdf-schema#comment',
	    'http://www.tao.lu/Ontologies/generis.rdf#userUILg',
	    'http://www.tao.lu/Ontologies/generis.rdf#userMail',
	    'http://www.tao.lu/Ontologies/generis.rdf#userLastName',
	    'http://www.tao.lu/Ontologies/generis.rdf#userFirstName',
	    'http://www.tao.lu/Ontologies/generis.rdf#userDefLg',
	    'http://www.tao.lu/Ontologies/generis.rdf#password',
	    'http://www.tao.lu/Ontologies/generis.rdf#login'
	);

	/**
	 * 
	 * @access public
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param taoMigration_models_classes_DistantDbConnector $dbConnector
	 * @param string $domain
	 * @param string $lang
	 */
	public function initDb(taoMigration_models_classes_DistantDbConnector $dbConnector,$lang){

		$this->oldDbWrapper = $dbConnector->getDbConnector();
		$this->oldDbWrapper->exec('SET SESSION SQL_MODE=\'ANSI_QUOTES\';');
		$this->oldDefaultLg = $lang;

	}
	
	/**
	 * 	 
	 * @access protected
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 */
	protected function __construct()
	{
		$this->currentDbWrapper = core_kernel_classes_DbWrapper::singleton()->dbConnector;
		$this->currentDefaultLg = core_kernel_classes_Session::singleton()->defaultLg;

	}


	/**
	 * @access public
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	*/
	private function switchToOldDbWrapper()
	{
		//common_Logger::i('Switch to OLD TAO DB');
		core_kernel_classes_DbWrapper::singleton()->dbConnector = $this->oldDbWrapper;
		core_kernel_classes_Session::singleton()->defaultLg = $this->oldDefaultLg;
	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param string $old
	 * @param string $new
	 * @return string|boolean
	 */
	private function addNewMigratedResource($old, $new)
	{
		if (!isset($this->migrationHistory[$old])) {
			$this->migrationHistory[$old] = $new;
			return true;
		} else return false;
	}

	/*
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 */
	private function getMigrationResourceUri($uri)
	{
		if (isset($this->migrationHistory[$uri])) {
			return $this->migrationHistory[$uri];
		} else {
			$ns = substr($uri, 0, strpos($uri, '#'));
			if(in_array($ns, $this->namespaceToIgnore)){
				return $uri;
			}
			return false;
		}
	}


	/**
	 * 	 
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	*/
	private function switchToNewDbWrapper()
	{
		//common_Logger::i('Switch to ACTUAL TAO DB');
		core_kernel_classes_DbWrapper::singleton()->dbConnector = $this->currentDbWrapper;
		core_kernel_classes_Session::singleton()->defaultLg = $this->currentDefaultLg;
	}

	/**
	 * 
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param $class core_kernel_classes_Class
	 */
	 private function migrateClass($class, $propertiesUriToSkip = array(), $propertiesUriToReplace = array())
	 {
		foreach ($propertiesUriToSkip as $uri) {
			$this->addNewMigratedResource($uri, $uri);
		}

		foreach ($propertiesUriToReplace as $old => $new) {
			$this->addNewMigratedResource($old, $new);
		}
		common_Logger::d('Start Migrating CLASS ' .$class);
		//migrate properties
		$this->migrateClassProperties($class);
		$this->migrateClassSubClasses($class);
		$this->migrateClassInstances($class);
		try{
			$this->handleMissingPropertyValue();
		}catch(common_exception_InconsistentData $e){
			
		}
		
		common_Logger::d('Finish Migrating CLASS ' .$class);


	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param $class core_kernel_classes_Class
	 */
	private function migrateClassSubClasses($class)
	{
		$this->switchToOldDbWrapper();
		common_Logger::d('Try to migrate Subclass of ' . $class);
		$newClass = $this->getMigrationClass($class);
		$subClasses = $class->getSubClasses();
		foreach ($subClasses as $subclass) {
			$newSubClass = $this->getMigrationResourceUri($subclass->getUri());
			if ($newSubClass == false) {		
				common_Logger::d('Try to migrate Subclass : ' . $subclass);
				$label = $subclass->getLabel();
				$comment = $subclass->getComment();	
				$this->switchToNewDbWrapper();
				$newSubClass = $newClass->createSubClass($label, $comment);
				if ($this->addNewMigratedResource($subclass->getUri(), $newSubClass->getUri()) === false) {
					throw new common_exception_InconsistentData('Subclass ' . $subclass . ' already added');
				}		
			}else {
				common_Logger::d('Already migrated resource ' . $subclass->getUri() . ' Skip creation');
			}
			$this->migrateClass($subclass);

		}
	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param  $class core_kernel_classes_Class
	 */
	private function migrateClassProperties($class)
	{
		$this->switchToOldDbWrapper();
		$newClass = $this->getMigrationClass($class);
		$props = $class->getProperties();

		foreach ($props as $prop) {
			$this->switchToOldDbWrapper();
			if ($this->getMigrationResourceUri($prop->getUri()) != false) {
				common_Logger::d('Already migrated resource ' . $prop->getUri() . ' Skip');
				continue;
			}
			$propLabel = $prop->getLabel();
			common_Logger::d('Try to migrate property : ' . $propLabel);
			$propComment = $prop->getComment();
			$propRange = $prop->getRange();

			common_Logger::d($propLabel . ' has range ' . $propRange);


			$this->switchToOldDbWrapper();
			$lgProp = new core_kernel_classes_Property(PROPERTY_IS_LG_DEPENDENT);
			$isLgDependant = $prop->getOnePropertyValue($lgProp);
			$isLgDependantBool = $isLgDependant == GENERIS_TRUE ? true : false;
			$widgetProp = new core_kernel_classes_Property(PROPERTY_WIDGET);
			$widget = $prop->getOnePropertyValue($widgetProp);


			$this->switchToNewDbWrapper();
			$newProp = $newClass->createProperty($propLabel, $propComment, $isLgDependantBool);
			common_Logger::d('New Property migrated : ' . $newProp . ' from ' . $prop);


			$newPropRange = $this->migratePropRange($propRange);
			if ($newPropRange != false) {
				$newProp->setRange($newPropRange);
			}
			else{
				common_Logger::e('Properties ' . $prop . ' have a bad range skip') ;
				continue;
			}
			if ($widget != null && $widget instanceof core_kernel_classes_Resource) {
				$newProp->setPropertyValue($widgetProp, $widget->getUri());
			}
			if ($this->addNewMigratedResource($prop->getUri(), $newProp->getUri()) === false) {
				throw new common_exception_InconsistentData('Properties ' . $prop . ' already added');
			}
		}
	}


	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param core_kernel_classes_Resource $propRange
	 */
	private function migratePropRange($propRange)
	{
				
		if ($propRange == null){
			common_Logger::e('Range should not be null');
			return false;
		}
		
		if ($propRange instanceof core_kernel_classes_Resource 
			&& 	$this->getMigrationResourceUri($propRange->getUri()) == true) {
			common_Logger::d('Skipped range already added ' . $propRange);
			$migratedRangeClass = $this->getMigrationClass($propRange);
			return $migratedRangeClass;
		}


		//range is class
		if ($propRange instanceof core_kernel_classes_Class) {

			common_Logger::d('Property Range need to be migrated too : ' . $propRange);

			$this->switchToOldDbWrapper();
			$listClass = new core_kernel_classes_Class(TAO_LIST_CLASS);
			$isList = $propRange->isSubClassOf($listClass);
			$fileClass = new core_kernel_classes_Class(CLASS_GENERIS_FILE);
			$isFile = $propRange->getUri() == CLASS_GENERIS_FILE || $propRange->isSubClassOf($fileClass);

			if ($isList) {

				common_Logger::d('Property Range is a list');
				$this->switchToOldDbWrapper();
				$label = $propRange->getLabel();
				$comment = $propRange->getComment();
				$this->switchToNewDbWrapper();
				$newList = $listClass->createSubClass($label, $comment);
				$this->addNewMigratedResource($propRange->getUri(), $newList->getUri());
				$this->migrateClassProperties($propRange);
				$this->migrateClassInstances($propRange);

				return $newList;

			} elseif ($isFile) {
				common_Logger::d('Property Range is a file');
				return $fileClass;
			}
			else {
				common_Logger::d('Property Range is a different class we need to migrate');
				$this->switchToOldDbWrapper();
				$parentClasses = $propRange->getParentClasses();

				$newParentClass = $this->migrateParentClasses($parentClasses,$propRange);
				
				return $newParentClass;
			}

		}
		common_Logger::e('Something wrong happen when importing range : ' . $propRange);
		return false;
	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param core_kernel_classes_Class $parentClasses
	 * @param core_kernel_classes_Class $class
	 */
	private function migrateParentClasses($parentClasses,$class)
	{
		common_Logger::d('Migrating Parent class');
		$this->switchToOldDbWrapper();
		$label = $class->getLabel();
		$comment = $class->getComment();


		foreach($parentClasses as $uri => $parentClass){
			if($uri == RDF_CLASS){
				continue;
			}
			if ($this->getMigrationResourceUri($parentClass->getUri()) == true) {
				common_Logger::d('ParentClasses already added ' . $parentClass);
				$newParentClass = $this->getMigrationClass($parentClass);
				$this->switchToNewDbWrapper();
				$newClass = $newParentClass->createSubClass($label,$comment);
				$this->addNewMigratedResource($class->getUri(), $newClass->getUri());
				return $newClass;
			}
			else{
				$this->switchToOldDbWrapper();
				return $this->migrateParentClasses($parentClass->getParentClasses(),$class);
			}
		}
		common_Logger::d($parentClass . ' is a direct subclass of RDF_CLASS');
		$classCLass = new core_kernel_classes_Class(RDF_CLASS);
		return $classCLass->createSubClass($label,$comment);

	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param core_kernel_classes_Class $class
	 * @return core_kernel_classes_Class
	 */
	private function getMigrationClass($class)
	{
		if (!$class instanceof core_kernel_classes_Class) {
			throw new common_exception_InvalidArgumentType(__CLASS__, __METHOD__, 1, 'core_kernel_classes_Class', $class);
		}
		$newClassUri = $this->getMigrationResourceUri($class->getUri());
		if ($newClassUri === false) {
			throw new common_exception_InconsistentData('Could not find resource ' . $class . ' in actual data');
		}
		$newClass = new core_kernel_classes_Class($newClassUri);
		return $newClass;
	}


	/**
	 * 
	 * @access
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @param core_kernel_classes_Property $property
	 * @throws common_exception_InconsistentData
	 * @return core_kernel_classes_Property
	 */
	private function getMigrationProperty(core_kernel_classes_Property $property)
	{
		$newPropUri = $this->getMigrationResourceUri($property->getUri());
		if ($newPropUri === false) {
			throw new common_exception_InconsistentData('Could not find resource ' . $property . ' in actual data');
		}
		$newProp = new core_kernel_classes_Property($newPropUri);
		return $newProp;
	}

	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @param core_kernel_classes_Class $class
	 * @throws common_exception_InconsistentData
	 * @throws Exception
	 */
	private function migrateClassInstances(core_kernel_classes_Class $class)
	{
			
		try{	
			$roleProperty = new core_kernel_classes_Property(PROPERTY_USER_ROLES);

			$this->switchToOldDbWrapper();
			$instances = $class->getInstances();
			$newClass = $this->getMigrationClass($class);
			$props = $class->getProperties(true);
	
			foreach ($instances as $instance) {
				try{
					common_Logger::d('START migrated resource ' . $instance->getUri());
					if ($this->getMigrationResourceUri($instance->getUri()) != false){
						common_Logger::d('Already migrated resource ' . $instance->getUri() . ' Skip');
						continue;
					}
					$this->switchToOldDbWrapper();
					$propsValues = $instance->getPropertiesValues($props);
					$newPropsValues = array();
					//remove all RDF_TYPE
					unset($propsValues[RDF_TYPE]);
					//retrieve all properties values
					foreach ($propsValues as $propsUri => $propsValueArray) {
						$this->switchToOldDbWrapper();
						$newProp = $this->getMigrationProperty(new core_kernel_classes_Property($propsUri));
						$this->switchToNewDbWrapper();
		
						//property should have been already created with class
						if ($newProp != false) {
		
							//retrieve property range to handle file
							$propRange = $newProp->getRange();
							if ($propRange instanceof core_kernel_classes_Resource) {
							    common_Logger::t('propRange : ' . $propRange . ' is a Resource ');
								$newPropsValueArray = array();
								// check propertyValues
								foreach ($propsValueArray as $propsValue) {
									$migratedValue = $this->migratePropValues($propsValue, $propRange);
									//tricky to refactor add a check before
									if($migratedValue == false){
									    common_Logger::d('Property value do not exist, add it to missingPropertiesValue for instance ' . $instance .
									               ' new property = ' . $newProp);
										$this->missingPropertyValues[$instance->getUri()][$newProp->getUri()] = $propsValue->getUri();
									}
									else{
										$newPropsValueArray[] = $migratedValue;
									}
								}
								$newPropsValues[$newProp->getUri()] = $newPropsValueArray;
		
							} else {
								throw new common_exception_InconsistentData('Range ' . $propRange . ' should be a resource');
							}
						} else {
							throw new common_exception_InconsistentData('Property ' . $newProp . ' is missing in actual data');
						}
					}
					$this->switchToNewDbWrapper();
		
					$newInstance = $newClass->createInstanceWithProperties($newPropsValues);
					common_Logger::d('New Resource migrated : ' . $newInstance . ' from ' . $instance);
		
					if ($this->addNewMigratedResource($instance->getUri(), $newInstance->getUri()) === false) {
						throw new common_exception_InconsistentData('Instance ' . $class->getUri() . ' already added');
					}
					$this->switchToOldDbWrapper();
					if ($class->isSubClassOf(new core_kernel_classes_Class(TAO_SUBJECT_CLASS)) || $class->getUri() == TAO_SUBJECT_CLASS) {
					    $this->switchToNewDbWrapper();
					    common_Logger::d('add role ' .INSTANCE_ROLE_DELIVERY .' to new subject instance ' . $newInstance);
						$newInstance->setPropertyValue($roleProperty, INSTANCE_ROLE_DELIVERY);
					}				
				} catch(common_exception_InconsistentData $e){
					common_Logger::e('Error migrating intance ' .$instance->getUri(). ' skip');
					continue;
				}
				
				common_Logger::d('FINISH migrated resource ' . $instance->getUri());
			}
				
		} catch(Exception $e){
			common_Logger::e('Error migrating intances ' .$e->getMessage());
			throw $e;

		}	
	}
	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 */
	private function handleMissingPropertyValue(){
		foreach($this->missingPropertyValues as $instanceUri => $propValueArray){
						
			$newResourceUri = $this->getMigrationResourceUri($instanceUri);
			if($newResourceUri == false){
					common_Logger::e($instanceUri . 'have not been migrated, need to set value : ' . implode('||',$propValueArray));
					continue;		
			}
			$newResource = new core_kernel_classes_Resource($newResourceUri);
			foreach($propValueArray as $propUri => $oldValuesUri){
	

				$prop = new core_kernel_classes_Property($propUri);
				$valuesUri =$this->getMigrationResourceUri($oldValuesUri);
				if($valuesUri == false){
				    $this->switchToNewDbWrapper();
				    $resourceValue = new core_kernel_classes_Resource($oldValuesUri);
				    common_Logger::d($oldValuesUri . ' is the value for property '. $prop .
				                ' and have not been migrated ' .
				                ' skip to next value, will come back later');	
				    continue;		
				}
				$this->switchToNewDbWrapper();
				$newResource->setPropertyValue($prop,$valuesUri);
			}

		}
	}

	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @param Literal|core_kernel_classes_Resource $propsValue
	 * @param core_kernel_classes_Resource $propRange
	 * @throws common_exception_InconsistentData
	 * @return string|core_kernel_versioning_File, 
	 */
	private function migratePropValues($propsValue, $propRange)
	{
	   
		//case resource
		if ($propsValue instanceof core_kernel_classes_Resource) {
		    //common_Logger::d('migrating PropsValues : ' . $propsValue . ' is a resource');

			// check range type not really usefull
			if ($propRange instanceof core_kernel_classes_Resource) {

				$fileClass = new core_kernel_classes_Class(CLASS_GENERIS_FILE);
				$isFile = $propRange->getUri() == CLASS_GENERIS_FILE
				|| $propRange->isSubClassOf($fileClass);

				//handle file
				if ($isFile) {
					common_Logger::t('Range is a file ' . $propsValue);
					try{
						$file = $this->migrateFile($propsValue);
					} catch(common_exception_FileSystemError $e){
						$file = 'missing file';
						common_Logger::e('Exception raised ' . $e->getMessage());
					}
					return $file;
				} //other resource
				else {
					$resourceMigrated = $this->getMigrationResourceUri($propsValue->getUri());
					if ($resourceMigrated != false) {
						return $resourceMigrated;
					} else {
						return false;
					}
				}
			} else {
				throw new common_exception_InconsistentData('Range ' . $propRange . ' should be a resource');
			}
		}

		//case Literals
		if ($propsValue instanceof core_kernel_classes_Literal) {
		    common_Logger::t('migrating PropsValues : ' . $propsValue . ' is a Litteral');
			return $propsValue;
		}
		common_Logger::e($propsValue . ' is neither a Resource or Litteral, it should not happen ');

	}

	/**
	 * @access private
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 * @param core_kernel_classes_Resource $file
	 * @return core_kernel_versioning_File
	 */
	private function migrateFile(core_kernel_classes_Resource $file)
	{
		$newFile = null;
		try{
			
			$this->switchToOldDbWrapper();
			$fileValues = $file->getPropertiesValues(array(
			new core_kernel_classes_Property(PROPERTY_FILE_FILEPATH),
			new core_kernel_classes_Property(PROPERTY_FILE_FILENAME)
			));
	
			if(!isset($fileValues[PROPERTY_FILE_FILENAME]) || !isset($fileValues[PROPERTY_FILE_FILEPATH])){
				throw new common_exception_InconsistentData('bad file structure for file ' .$file->getUri());
			}
			$filename = $fileValues[PROPERTY_FILE_FILENAME][0];
			$filePath = $fileValues[PROPERTY_FILE_FILEPATH][0];
	
			$oldUri = substr($filePath, strpos($filePath, 'data') + 5);
			$oldShortUri = substr($oldUri, 0, strpos($oldUri, DIRECTORY_SEPARATOR));
			$this->switchToNewDbWrapper();
			$repository = $this->getDefaultFileSource();
			$newPath = $oldShortUri . DIRECTORY_SEPARATOR . 'itemContent' . DIRECTORY_SEPARATOR . $this->currentDefaultLg;
			common_Logger::d('copy folder ' . $filePath . ' to ' . $newPath);
			if(file_exists($filePath)){
				if (!helpers_File::copy($filePath, $repository->getPath() . $newPath)) {
					throw new common_exception_FileSystemError('Fail copy folder ' . $filePath . ' to ' . $newPath);
				}
			}
			else{
				throw new common_exception_FileSystemError('Fail copy folder ' . $filePath . ' to ' . $newPath);
			}
			common_Logger::d('importing file into actual db');
			$newFile = $repository->createFile($filename, $newPath);
		
			
					
		} catch(Exception $e){
			common_Logger::e('Error importing File '.$e->getMessage());
			throw $e;

		}
		return $newFile;

	}

	/**
	 * @access public
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 */
	private function getDefaultFileSource()
	{
		return taoItems_models_classes_ItemsService::singleton()->getDefaultFileSource();
	}


	/**
	 * 
	 * @access public
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @throws Exception
	 */
	public function migrateItems()
	{
		try{
			
			$itemsClass = new core_kernel_classes_Class(TAO_ITEM_CLASS);
			$skipProperties = array();
			$this->switchToOldDbWrapper();
			$countOld = count($itemsClass->getInstances(true));
			common_Logger::i('START MIGRATING ITEMS : ' .$countOld . ' Items were found in SOURCE DATABASE');
			$this->switchToNewDbWrapper();
			$countBefore = count($itemsClass->getInstances(true));
			
			$switchProperties = array('http://www.tao.lu/Ontologies/TAOItem.rdf#VersionedItemContentFolder' => TAO_ITEM_CONTENT_PROPERTY);
			$this->migrateClass($itemsClass, $skipProperties, $switchProperties);
			
			$this->switchToNewDbWrapper();
			$countAfter = count($itemsClass->getInstances(true));
			$count = $countAfter - $countBefore;
			common_Logger::i('FINISH MIGRATING ITEMS : ' .$count . ' out of ' . $countOld . ' Items have been added');


							
		} catch(Exception $e){
			common_Logger::e('Error importing items '.$e->getMessage());
			throw $e;

		}	

	}


	/**
	 * 
	 * @access public
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @throws Exception
	 */
	public function migrateSubjects()
	{
			
		try{
			
			$subjectClass = new core_kernel_classes_Class('http://www.tao.lu/Ontologies/TAOSubject.rdf#Subject');
			$skipProperties = array();
			$this->switchToOldDbWrapper();
			$countOld = count($subjectClass->getInstances(true));
			common_Logger::i('START MIGRATING ITEMS : ' .$countOld . ' Testtakers were found in SOURCE DATABASE');
			$this->switchToNewDbWrapper();

			$countBefore = count($subjectClass->getInstances(true));
	
			$switchProperties = array(
	            'http://www.tao.lu/Ontologies/TAO.rdf#LangEN' => 'http://www.tao.lu/Ontologies/TAO.rdf#Langen-US',
	            'http://www.tao.lu/Ontologies/TAO.rdf#LangFR' => 'http://www.tao.lu/Ontologies/TAO.rdf#Langfr-FR'
	
	        );
	        $this->switchToOldDbWrapper();
	        $this->migrateClass($subjectClass, $skipProperties, $switchProperties);
		
	        $this->switchToNewDbWrapper();
	        $newTesttakers = $subjectClass->getInstances(true);

			$countAfter = count($newTesttakers);
			$count = $countAfter - $countBefore;

			common_Logger::i('FINISH MIGRATING TESTTAKERS : ' .$count . ' out of ' . $countOld . ' testtakers have been added');
	        
				
		} catch(Exception $e){
			common_Logger::e('Error importing subject '.$e->getMessage());
			throw $e;

		}

	}
	
    /**
     * 
     * @access private
     * @author "Lionel Lecaque, <lionel@taotesting.com>"
     * @param array $oldRoles
     * @return array
     */
	private function migrateRoles($oldRoles){
	    $userService = core_kernel_users_Service::singleton();
	   
	    $newRoles = array();
	    foreach ($oldRoles as $role){
	    
	        $this->switchToOldDbWrapper();
	        $roleUri = $role->getUri();
	        $newRoleUri = $this->getMigrationResourceUri($roleUri);
	        if($newRoleUri == false){
                // role do not exist need to create
                $roleLabel = $role->getLabel();
                $this->switchToNewDbWrapper();
                $newRole = $userService->addRole($roleLabel);
                common_Logger::d('New Role add ' . $newRole);
                if ($this->addNewMigratedResource($roleUri, $newRole->getUri()) == false) {
                    common_Logger::e('Role ' . $newRole->getUri() . ' already added');
                }
	        }
	        else {
	        		$newRole = new core_kernel_classes_Resource($newRoleUri);
	        		common_Logger::d('Role already exist ' . $newRole->getUri());
	        }
	        $newRoles[] = $newRole;
	    
	    }
	    return $newRoles;
	}
	
	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 */
	private function initUsersMap(){
	    $roleMap = array(
	        'http://www.tao.lu/Ontologies/TAO.rdf#TaoManagerRole' => 'http://www.tao.lu/Ontologies/TAO.rdf#GlobalManagerRole',
	        'http://www.tao.lu/Ontologies/TAO.rdf#WorkflowUserRole' => 'http://www.tao.lu/Ontologies/TAO.rdf#WorkflowRole'
	    );
	    
	    $langMap = array(
	        'http://www.tao.lu/Ontologies/TAO.rdf#LangEN' => 'http://www.tao.lu/Ontologies/TAO.rdf#Langen-US',
	        'http://www.tao.lu/Ontologies/TAO.rdf#LangFR' => 'http://www.tao.lu/Ontologies/TAO.rdf#Langfr-FR'
	    
	    );
	     
	    foreach ($roleMap as $old => $new) {
	        $this->addNewMigratedResource($old, $new);
	    }
	    
	    foreach ($langMap as $old => $new) {
	        $this->addNewMigratedResource($old, $new);
	    
	    }
	}
	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @param core_kernel_classes_Class $role
	 */
	private function migrateRolesUsers(core_kernel_classes_Class $role){
	    $userService = core_kernel_users_Service::singleton();
	    
	    $this->switchToOldDbWrapper();
	    $users = $role->getInstances();
	    $countOld = count($users);
	    common_Logger::i('START MIGRATING USERS : ' .$countOld . ' users were found in SOURCE DATABASE FOR ROLE ' . $role);
	    
	    
	    $this->switchToNewDbWrapper();
	    $newUerClass = new core_kernel_classes_Class(CLASS_TAO_USER);
	    $countBefore = count($newUerClass->getInstances());
	     
	    
	    foreach ($users as $uri =>$user){
	        //TODO add option to let user decide
	        if($uri =='http://www.tao.lu/Ontologies/TAO.rdf#installator'){
	            common_Logger::i('installator was a technical user used during installation, not needed anymore it will be skipped');
	            continue;
	        }
	        if(strpos($uri,'#superUser') != false ){
	            common_Logger::i('superUser was previous admin and as you have already recreate a superUseradmin has been skipped');
	            continue;
	        }
	    
	        try {
	            $this->switchToOldDbWrapper();
	            $oldRoles = $user->getPropertyValuesCollection(new core_kernel_classes_Property(RDF_TYPE));
	            $this->migrateOneUSer($user,$oldRoles);
	            	
	        }catch(core_kernel_users_Exception $e1){
	            common_Logger::i('Login already exist skip user');
	            continue;
	        }catch (common_exception_InconsistentData $e2){
	            common_Logger::i($e2->getMessage() );
	            continue;
	        }

	    }
	    $this->switchToNewDbWrapper();
	    $countAfter = count($newUerClass->getInstances());
	    $count = $countAfter - $countBefore;
	    common_Logger::i('FINISH MIGRATING USERS : ' .$count . ' out of ' . $countOld . ' users have been added for ROLE ' .$role);
	     
	}

	/**
	 * @access public
	 * @author Lionel Lecaque, <lionel@taotesting.com>
	 */
	public function migrateUsers()
	{
		try{

            $this->initUsersMap();          
            $this->switchToNewDbWrapper();
            $managerRoles = new core_kernel_classes_Class('http://www.tao.lu/Ontologies/TAO.rdf#TaoManagerRole');
    	    
            
    	    //find all roles
    	    $this->switchToOldDbWrapper();
    	    $backoffice = new core_kernel_classes_Class('http://www.tao.lu/Ontologies/TAO.rdf#BackOffice');
    	    $otherRoles = $backoffice->getInstances();
    	    foreach ($otherRoles as $role){
    	        //migrate all user for one role
    	        $roleClass = new core_kernel_classes_Class($role->getUri());
    	        //migrate each roles'users
    	        $this->migrateRolesUsers($roleClass); 
    	    }
    	    

		} catch(Exception $e){
			common_Logger::e('Error importing users '.$e->getMessage());
			throw $e;

		}
	}
	/**
	 * 
	 * @access private
	 * @author "Lionel Lecaque, <lionel@taotesting.com>"
	 * @param core_kernel_classes_Resource $user
	 * @param array $oldRoles
	 * @throws common_exception_InconsistentData
	 * @throws core_kernel_users_Exception
	 */
	private function migrateOneUSer(core_kernel_classes_Resource $user, $oldRoles) {
	 
	    $this->switchToOldDbWrapper();

	    $userPropsValues = $user->getPropertiesValues($this->userProps);
	    if(!isset($userPropsValues['http://www.tao.lu/Ontologies/generis.rdf#login'])){
	        throw new common_exception_InconsistentData('user ' . $user . ' do not have login skip');
	    }
	    if(!isset($userPropsValues['http://www.tao.lu/Ontologies/generis.rdf#password'])){
	        throw new common_exception_InconsistentData('user ' . $user . ' do not have password skip');
	    }
	    	
	    common_Logger::d('Retieve user ' . $user);
	    $newRoles = $this->migrateRoles($oldRoles);
	    $this->switchToNewDbWrapper();
	    
	    $login = $userPropsValues['http://www.tao.lu/Ontologies/generis.rdf#login'][0]->literal;
	    $password = $userPropsValues['http://www.tao.lu/Ontologies/generis.rdf#password'][0]->literal;
	    $newPropValues = array();
        foreach ($userPropsValues as $propUri => $value) {
            if ($propUri == 'http://www.tao.lu/Ontologies/generis.rdf#login' || $propUri == 'http://www.tao.lu/Ontologies/generis.rdf#password') {
                continue;
            }
            if ($propUri == 'http://www.tao.lu/Ontologies/generis.rdf#userUILg') {
                
                if ($value[0] instanceof core_kernel_classes_Resource) {
                    $newLangUi = $this->getMigrationResourceUri($value[0]->getUri());
                    $newPropValues[$propUri] = $newLangUi;
                } else {
                    throw new common_exception_InconsistentData('User language ' . $value[0] . ' should be resource');
                }
                continue;
            }
            if ($propUri == 'http://www.tao.lu/Ontologies/generis.rdf#userDefLg') {
                if ($value[0] instanceof core_kernel_classes_Resource) {
                    $newLangUi = $this->getMigrationResourceUri($value[0]->getUri());
                    $newPropValues[$propUri] = $newLangUi;
                } else {
                    common_Logger::d('no lang found set defaut lg');
                    $newPropValues[$propUri] = 'http://www.tao.lu/Ontologies/TAO.rdf#Lang' . $this->currentDefaultLg;
                }
                continue;
            }
            
            $newPropValues[$propUri] = $value[0];
        }
	    
	    $newRole = array_shift($newRoles);

	    common_Logger::d('CREATE USER ' . $login . ' pass :' . $password . ' with new role : ' . implode('|',$newRoles));
	    try {
	        $userService = core_kernel_users_Service::singleton();
	        $newUser = $userService->addUser($login,$password,$newRole,new core_kernel_classes_Class(CLASS_TAO_USER));
	        foreach ($newRoles as $role){
	            $userService->attachRole($newUser,$role);
	        }
	    
	        common_Logger::d('USER CREATED setPropertiesValues ' . $newUser->getUri() );
	        $newUser->setPropertiesValues($newPropValues);
	        if($this->addNewMigratedResource($user->getUri(),$newUser->getUri()) == false){
	            throw new common_exception_InconsistentData('User ' . $newUser->getUri() . ' already added');
	        }
	    }catch(core_kernel_users_Exception $e){
            throw $e;
	    }
	}


}
