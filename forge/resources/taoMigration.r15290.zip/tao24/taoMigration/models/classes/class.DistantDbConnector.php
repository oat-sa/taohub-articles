<?php
/**
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Copyright (c) 2013 (original work) Open Assessment Techonologies SA (under the project TAO-PRODUCT);
 */

/**
 * @author  Lionel Lecaque, <lionel@taotesting.com>
 * @package taoMigration
 * @subpackage models_classes
 */

class taoMigration_models_classes_DistantDbConnector
{

	private $dbConnector;

	/**
	 * @access public
	 * @author  Lionel Lecaque, <lionel@taotesting.com>
	 * @param string $host
	 * @param string $user
	 * @param string $pass
	 * @param string $driver
	 * @param string $dbName
	 */
	public function __construct( $host = 'localhost', $user = 'root', $pass = '', $driver = 'mysql', $dbName = ''){
		$options = array(PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_BOTH,
		PDO::ATTR_PERSISTENT => false,
		PDO::ATTR_EMULATE_PREPARES => false);

		$dsn = $driver . ":dbname=".$dbName.";host=".$host.";charset=utf8";
		$pdo = new PDO($dsn,$user,$pass,$options);

		$this->setDbConnector($pdo);
	}

	/**
	 * @access public
	 * @author  Lionel Lecaque, <lionel@taotesting.com>
	 * @param unknown_type $dbConnector
	 */
	public function setDbConnector($dbConnector)
	{
		$this->dbConnector = $dbConnector;
	}

	/*
	 * @access public
	 * @author  Lionel Lecaque, <lionel@taotesting.com>
	 */
	public function getDbConnector()
	{
		return $this->dbConnector;
	}


}
