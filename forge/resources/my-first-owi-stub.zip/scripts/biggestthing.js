/*
 * Free Form Item initialization.
 * @param {Function} onValidate - function executed once the validate button is clicked 
 */
var init = function (onValidate) {
	window.changing = false; // Indicates if the currently selected thing is changing.
	changeButtonState($('#next, #previous', '#validate'), true); // Make sure that all buttons are disabled until the item is fully loaded.
	
	// Only initialize first image when all are loaded.
	// (uses image preloader jQuery plugin)
	$('#image_selector .thing').imgpreload(function () {
		window.currentThing = -1; // We set the current thing out of bounds during image preload.
		window.countThing = $('#image_selector .thing').length; // Global counter of selectabe things in this item.
		$('#next, #validate').attr('disabled', false); // User is able at first to go only to a next thing or validate immediately.
		changeThing('right'); // First thing is shown on the screen.
	});
	

	// Next button click event binding.
	$('#next').bind('click', function(e) { 
		e.preventDefault();	
		onNextClicked(e);
	});
	
	// Previous button click event binding.
	$('#previous').bind('click', function(e) {
		e.preventDefault();	
		onPreviousClicked(e);
	});
	
	// Validate button click event binding.
	$('#validate').bind('click', function(e) {
		e.preventDefault();	
		onValidate();
	});
};

/*
 * Next button click event handler.
 */
var onNextClicked = function (e) {
	if (window.currentThing < window.countThing - 1) {
		// Other images are still available by rotating right.
		changeThing('right');
	}
};

/*
 * Previous button click event handler.
 */
var onPreviousClicked = function (e) {
	if (window.currentThing > 0) {
		// Other images are still available by rotating left.
		changeThing('left');
	}
};

/*
 * This method is invoked when the end-user clicks on the next or the previous button.
 * As a result, a new image illustrating a "thing" is shown on the screen, depending on
 * the value of the dir parameter.
 * 
 * @param dir string 'left' or 'right'.
 */
var changeThing = function (dir) {
	if (!window.changing) { 
		$things = $('#image_selector .thing');
		
		// Hide current thing
		window.changing = true;
		$things.eq(window.currentThing).fadeOut(400, function () {
			// Now show the next/previous one.
			var increment = (dir == 'left') ? (-1) : 1;
			window.currentThing += increment;
			updateNavigation();
			$things.eq(window.currentThing).fadeIn(400);
			
			window.changing = false;
		});	
	}
};

/*
 * This method is invoked after a "thing" has changed on the screen, to check wheter or not
 * Next or Previous buttons have to be disabled.
 */
var updateNavigation = function () {
	if (window.currentThing + 1 == window.countThing) {
		// The displayed thing is the last one of the list. Next button should be disabled.
		changeButtonState($('#previous'), false);
		changeButtonState($('#next'),true);
	}
	else if (window.currentThing === 0) {
		// The displayed thing is the first one of the list. Previous button should be disabled.
		changeButtonState($('#previous'), true) ;
		changeButtonState($('#next'), false);
	}
	else {
		changeButtonState($('#next, #previous'), false);
	}
};

/*
 * This method allows you to disable or enable a particular button.
 * 
 * @param  $button jQuery The button you want to disable or enable.
 * @param disabled boolean True if you want the button to be disabled. Otherwise, false.
 */
var changeButtonState = function ($button, disabled) {
		
	if (disabled) {
		$button.addClass('disabled');
		$button.attr('disabled', true);
	}	
	else {
		$button.removeClass('disabled');
		$button.removeAttr('disabled');
	}
};



 /*
  * This is where we will work together.
  */
window.onItemApiReady = function(itemApi){
    init(function onValidateClicked(e){
   
        

    });
};


